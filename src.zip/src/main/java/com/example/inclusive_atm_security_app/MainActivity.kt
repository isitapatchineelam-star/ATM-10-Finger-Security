package com.example.inclusive_atm_security_app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.*
import kotlin.random.Random

class MainActivity : FragmentActivity() { // FragmentActivity kavali BiometricPrompt kosam

    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts.language = Locale("te", "IN") // Telugu voice
            }
        }

        setContent {
            MaterialTheme {
                InclusiveATMApp(tts, this)
            }
        }
    }

    override fun onDestroy() {
        tts.shutdown()
        super.onDestroy()
    }
}

@Composable
fun InclusiveATMApp(tts: TextToSpeech, activity: FragmentActivity) {
    var currentScreen by remember { mutableStateOf("registration") }

    when (currentScreen) {
        "registration" -> FingerRegistrationScreen {
            currentScreen = "login"
            tts.speak("10 fingers register ayyayi. Ippudu login cheddam", TextToSpeech.QUEUE_FLUSH, null, null)
        }
        "login" -> ATMLoginScreen(tts, activity) {
            currentScreen = "dashboard"
            tts.speak("ATM Unlock ayyindi", TextToSpeech.QUEUE_FLUSH, null, null)
        }
        "dashboard" -> ATMDashboard {
            currentScreen = "login"
        }
    }
}

// Screen 1: 10-Finger Registration
@Composable
fun FingerRegistrationScreen(onRegistrationComplete: () -> Unit) {
    var fingersRegistered by remember { mutableStateOf(0) }

    val fingerNames = listOf(
        "Kudi Cheyi Botana Velu", "Kudi Cheyi Chupudu Velu", "Kudi Cheyi Madhya Velu",
        "Kudi Cheyi Uthara Velu", "Kudi Cheyi Chinna Velu",
        "Edama Cheyi Botana Velu", "Edama Cheyi Chupudu Velu", "Edama Cheyi Madhya Velu",
        "Edama Cheyi Uthara Velu", "Edama Cheyi Chinna Velu"
    )

    LaunchedEffect(fingersRegistered) {
        if (fingersRegistered == 10) {
            kotlinx.coroutines.delay(1000)
            onRegistrationComplete()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("10-Finger Registration", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(30.dp))
        LinearProgressIndicator(progress = fingersRegistered / 10f, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(10.dp))
        Text("Registered: $fingersRegistered / 10", fontSize = 18.sp)
        Spacer(modifier = Modifier.height(30.dp))

        if (fingersRegistered < 10) {
            Text(
                "Ippudu Scan Chey:\n${fingerNames[fingersRegistered]}",
                fontSize = 18.sp, color = Color.Blue, textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(30.dp))
            Button(onClick = { fingersRegistered++ }) {
                Text("Finger Scan Ayindi - Next")
            }
        } else {
            Text("10 Fingers Register Ayyayi ✅", fontSize = 18.sp, color = Color.Green)
        }
    }
}

// Screen 2: 10-Finger Login - Ikkade Main Logic
@Composable
fun ATMLoginScreen(tts: TextToSpeech, activity: FragmentActivity, onLoginSuccess: () -> Unit) {
    val context = LocalContext.current
    var currentScan by remember { mutableStateOf(0) }
    var status by remember { mutableStateOf("ATM Access Kosam Fingers Verify Chey") }

    val fingerNames = listOf(
        "Kudi Botana Velu", "Kudi Chupudu Velu", "Kudi Madhya Velu", "Kudi Uthara Velu", "Kudi Chinna Velu",
        "Edama Botana Velu", "Edama Chupudu Velu", "Edama Madhya Velu", "Edama Uthara Velu", "Edama Chinna Velu"
    )

    // Random ga 3 fingers select chestam
    val fingersToScan = remember {
        fingerNames.indices.shuffled().take(3)
    }

    fun showBiometricPrompt() {
        val executor = ContextCompat.getMainExecutor(context)
        val biometricPrompt = BiometricPrompt(activity, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    currentScan++
                    status = "$currentScan/3 Fingers Verified ✅"
                    tts.speak("$currentScan verify ayyindi", TextToSpeech.QUEUE_FLUSH, null, null)

                    if (currentScan == 3) {
                        onLoginSuccess()
                    }
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    status = "Error: $errString"
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    status = "Verification Failed ❌ Malli Try Chey"
                }
            })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Step ${currentScan + 1}/3")
            .setSubtitle("${fingerNames[fingersToScan[currentScan]]} scan chey")
            .setNegativeButtonText("Cancel")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Multi-Finger ATM Login", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(30.dp))

        if (currentScan < 3) {
            Text(
                "Scan Chey: ${fingerNames[fingersToScan[currentScan]]}",
                fontSize = 20.sp, color = Color.Blue, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
        LinearProgressIndicator(progress = currentScan / 3f, modifier = Modifier.fillMaxWidth())
        Spacer(modifier = Modifier.height(10.dp))
        Text(status, fontSize = 16.sp, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(10.dp))
        Text("Progress: $currentScan / 3", fontSize = 16.sp)
        Spacer(modifier = Modifier.height(40.dp))

        if (currentScan < 3) {
            Button(onClick = { showBiometricPrompt() }) {
                Text("Finger Scan Chey (${currentScan + 1}/3)")
            }
        }
    }
}

// Screen 3: ATM Dashboard
@Composable
fun ATMDashboard(onLogout: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("ATM Dashboard", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Green)
        Spacer(modifier = Modifier.height(30.dp))
        Text(
            "10-Finger Security tho\nATM Unlock Ayindi 🔓",
            fontSize = 20.sp, textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(40.dp))
        Button(onClick = onLogout, colors = ButtonDefaults.buttonColors(containerColor = Color.Red)) {
            Text("Logout")
        }
    }
}